test
UTF_noBOM.java
测试
中文